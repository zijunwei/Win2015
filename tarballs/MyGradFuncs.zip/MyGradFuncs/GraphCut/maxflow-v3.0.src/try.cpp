#include <stdio.h>
#include "try.h"

int main()
{
    A b;
    b.a = 5;
    printf("Hello world %d\n", b.a);
    return 0;
}
