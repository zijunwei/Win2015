typedef struct A{
        int a;
} A ;
