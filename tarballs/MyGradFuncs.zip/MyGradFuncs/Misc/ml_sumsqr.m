function a = ml_sumsqr(Data)
    a = sum(sum(Data.^2));
