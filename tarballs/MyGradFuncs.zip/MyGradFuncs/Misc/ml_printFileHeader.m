function ml_printFileHeader()
    fprintf('%% By: Minh Hoai Nguyen (minhhoai@cs.stonybrook.edu)\n');
    fprintf('%% Created: %s\n', date);
    fprintf('%% Last modified: %s\n', date);
    